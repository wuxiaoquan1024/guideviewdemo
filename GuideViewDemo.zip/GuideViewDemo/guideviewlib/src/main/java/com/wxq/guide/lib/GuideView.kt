package com.wxq.guide.lib

import android.content.Context
import android.content.res.TypedArray
import android.graphics.*
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.TextView

class GuideView(context: Context, attr: AttributeSet?, defaultTheme: Int) : FrameLayout(context, attr, defaultTheme) {

    private var finishListener: OnGuidleFinishListener? = null
    private val itemList: ArrayList<GuideItem> = ArrayList()

    private val mPaint: Paint = Paint()

    /*
        虚线画笔
     */
    private val mDashPaint: Paint = Paint()

    /*
        三角形画笔
     */
    private val mTrianglePaint: Paint = Paint()



    private val mTextPaint: Paint = Paint()

    // 指示器半径
    private var mIndicatorRadius: Int

    //指示器的文字大小
    private var mIndicatorTextSize: Int

    private val mIndicatorBg: Int
    private val mIndicatorColor: Int

    private val dpBase: Int

    private val textView: TextView

    private var currentItem: GuideItem? = null

    private var currentIndex: Int = 0

    private val maskColor: Int

    var dashDrawable: Drawable? = null

    private val dashLenght: Int

    private val sideLenght: Int

    private val textLayoutParams: LayoutParams

    var finish = false

    constructor(context: Context, attr: AttributeSet?) : this(context, attr, -1)

    constructor(context: Context) : this(context, null)

    init {
        //需要关闭掉硬件加速,不然绘制paint 的xfermode 异常
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)

        dpBase = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1f, context.resources.displayMetrics).toInt()
        val ta: TypedArray = context.obtainStyledAttributes(attr, R.styleable.GuideView, defaultTheme, -1)
        mIndicatorRadius = ta.getDimensionPixelOffset(R.styleable.GuideView_indicator_radius, 8 * dpBase)
        mIndicatorTextSize = ta.getDimension(R.styleable.GuideView_indicator_textSize, 14f).toInt()
        maskColor = ta.getColor(R.styleable.GuideView_mask_color, Color.parseColor("#99000000"))
        dashLenght = ta.getDimensionPixelOffset(R.styleable.GuideView_dash_lenght, 40)
        sideLenght = ta.getDimensionPixelOffset(R.styleable.GuideView_side_lenght, 15)
        val triangleColor = ta.getColor(R.styleable.GuideView_triangle_color, Color.WHITE)
        val textColor = ta.getColor(R.styleable.GuideView_text_color, Color.WHITE)
        mIndicatorColor = ta.getColor(R.styleable.GuideView_indicator_textColor, Color.WHITE)
        mIndicatorBg = ta.getColor(R.styleable.GuideView_indicator_bg, Color.WHITE)
        ta.recycle()

        mPaint.isAntiAlias = true
        mDashPaint.isAntiAlias = true
        mDashPaint.style = Paint.Style.STROKE
        mDashPaint.strokeWidth = dpBase.toFloat()
        mDashPaint.color = Color.WHITE

        mTrianglePaint.isAntiAlias = true
        mTrianglePaint.style = Paint.Style.FILL
        mTrianglePaint.color = triangleColor

        mTextPaint.isAntiAlias = true
        mTextPaint.textSize = mIndicatorTextSize.toFloat()
        mTextPaint.color = mIndicatorColor
        mTextPaint.textAlign = Paint.Align.CENTER

        textView = TextView(context)
        textView.maxWidth= 240 * dpBase
        textView.setTextColor(textColor)
        textLayoutParams = LayoutParams(WRAP_CONTENT, WRAP_CONTENT)
        addView(textView, textLayoutParams)

        dashDrawable = resources.getDrawable(R.drawable.shape_dash_bg)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {

        if (childCount == 0) {
            return super.onLayout(changed, left, top, right, bottom)
        }

        if (childCount > 1) {
            throw IllegalArgumentException("child only one")
        }

        val child = getChildAt(0)
        if (child !== this.textView) {
            throw IllegalArgumentException("add view not support")
        }

        if (currentItem == null) {
            super.onLayout(changed, left, top, right, bottom)
            return
        }

        if (textLayoutParams.x == -1 || textLayoutParams.y == -1) {
            updateTextLayoutParams()
        }

        child.layout(textLayoutParams.x, textLayoutParams.y, textLayoutParams.x + child.measuredWidth, textLayoutParams.y + child.measuredHeight)
    }

    override fun dispatchDraw(canvas: Canvas?) {
        if (!finish && currentItem != null) {
            canvas?.let {
                drawMask(canvas)
                drawDaskLine(canvas)
                drawIndicator(canvas)
            }
        }
        super.dispatchDraw(canvas)
    }

    /**
     * 绘制虚线
     */
    private fun drawDaskLine(canvas: Canvas) {
        val dashWidth = 5 * dpBase.toFloat()
        mDashPaint.pathEffect = DashPathEffect(floatArrayOf(dashWidth, dashWidth), dashWidth)
        currentItem?.run {
            val triangleCenLen = Math.sin(Math.PI / 3) * sideLenght
            val halfSide = sideLenght / 2
            val offset = 15 * dpBase
            val path = Path()
            val trianglePath = Path()
            var cenX: Float = rect.centerX().toFloat()
            var cenY: Float = rect.centerY().toFloat()
            val halfLenght = dashLenght / 2
            var angle: Float = Float.MAX_VALUE
            var px: Float = 0f
            var py: Float = 0f
            when(currentItem?.oritation) {
                Oritation.Left -> {
                    val lastX = (rect.left - dashLenght - offset).toFloat()
                    path.moveTo((rect.left - offset).toFloat(), cenY)
                    path.lineTo(lastX, cenY)

                    trianglePath.moveTo((lastX - triangleCenLen).toFloat(), cenY)
                    trianglePath.lineTo(lastX, cenY - halfSide)
                    trianglePath.lineTo(lastX, cenY + halfSide)
                }

                Oritation.BOTTOM -> {
                    val lastY = (rect.bottom + dashLenght + offset).toFloat()
                    path.moveTo(cenX, (rect.bottom - offset).toFloat())
                    path.lineTo(cenX, lastY)

                    trianglePath.moveTo(cenX, (lastY + triangleCenLen).toFloat())
                    trianglePath.lineTo(cenX - halfSide, lastY)
                    trianglePath.lineTo(cenX + halfSide, lastY)
                }

                Oritation.RIGHT -> {
                    val lastX = (rect.right + dashLenght + offset).toFloat()
                    path.moveTo((rect.right + offset).toFloat(), cenY)
                    path.lineTo(lastX, cenY)

                    trianglePath.moveTo((lastX + triangleCenLen).toFloat(), cenY)
                    trianglePath.lineTo(lastX, cenY - halfSide)
                    trianglePath.lineTo(lastX, cenY + halfSide)
                }

                Oritation.TOP -> {
                    val lastY = (rect.top - dashLenght - offset).toFloat()
                    path.moveTo(cenX, (rect.top - offset).toFloat())
                    path.lineTo(cenX, lastY)

                    trianglePath.moveTo(cenX, (lastY - triangleCenLen).toFloat())
                    trianglePath.lineTo(cenX - halfSide, lastY)
                    trianglePath.lineTo(cenX + halfSide, lastY)
                }

                Oritation.LEFT_BOTTOM -> {
                    val lastX = cenX - offset - halfLenght
                    val lastY = (rect.bottom + dashLenght + offset).toFloat()
                    path.moveTo(cenX - offset, (rect.bottom + offset).toFloat())
                    path.quadTo(cenX - halfLenght -offset, (rect.bottom + offset + halfLenght).toFloat(), lastX, lastY)

                    trianglePath.moveTo(lastX, (lastY + triangleCenLen).toFloat())
                    trianglePath.lineTo(lastX - halfSide, lastY)
                    trianglePath.lineTo(lastX + halfSide, lastY)
                }

                Oritation.RIGHT_BOTTOM -> {
                    val lastX = cenX + halfLenght + offset
                    val lastY = (rect.bottom + dashLenght + offset).toFloat()
                    path.moveTo(cenX + offset, (rect.bottom + offset).toFloat())
                    path.quadTo(cenX + halfLenght + offset, (rect.bottom + halfLenght + offset).toFloat(), lastX, lastY)

                    trianglePath.moveTo(lastX, (lastY + triangleCenLen).toFloat())
                    trianglePath.lineTo(lastX - halfSide, lastY)
                    trianglePath.lineTo(lastX + halfSide, lastY)
                }

                Oritation.LEFT_TOP -> {
                    val lastX = cenX - halfLenght - offset
                    val lastY = (rect.top - dashLenght - offset).toFloat()
                    path.moveTo(cenX - offset, (rect.top - offset).toFloat())
                    path.quadTo(cenX - offset, (rect.top - halfLenght - offset).toFloat(), lastX, lastY)

                    trianglePath.moveTo(lastX, (lastY - triangleCenLen).toFloat())
                    trianglePath.lineTo(lastX - halfSide, lastY)
                    trianglePath.lineTo(lastX + halfSide, lastY)
                    angle = -38f
                    px = lastX
                    py = lastY
                }

                Oritation.RIGHT_TOP -> {
                    val lastX = cenX + halfLenght + offset
                    val lastY = (rect.top - dashLenght - offset).toFloat()
                    path.moveTo(cenX + offset, (rect.top - offset).toFloat())
                    path.quadTo(cenX + halfLenght + offset, (rect.top - halfLenght - offset).toFloat(), lastX, lastY)
                    trianglePath.moveTo(lastX, (lastY - triangleCenLen).toFloat())
                    trianglePath.lineTo(lastX - halfSide, lastY)
                    trianglePath.lineTo(lastX + halfSide, lastY)
                }
            }

            canvas.drawPath(path, mDashPaint)

            canvas.save()
            if (angle != Float.MAX_VALUE) {
                canvas.clipRect(px - sideLenght, py - sideLenght, px + sideLenght, py + sideLenght)
                canvas.rotate(angle, px, py)
            }
            canvas.drawPath(trianglePath, mTrianglePaint)
            canvas.restore()
        }
    }

    /**
     * 更新文字提示文字
     */
    private fun updateTextLayoutParams() {
        currentItem?.run {
            val offset = 22 * dpBase
            val textOffset = 24 * dpBase
            var cenX: Float = rect.centerX().toFloat()
            var cenY: Float = rect.centerY().toFloat()
            val halfLenght = dashLenght / 2
            when(currentItem?.oritation) {
                Oritation.Left -> {
                    val lastX = (rect.left - dashLenght - offset).toFloat()
                    textLayoutParams.x = (lastX - textView.measuredWidth - textOffset).toInt()
                    textLayoutParams.y = (cenY - textView.measuredHeight / 2).toInt()
                }

                Oritation.BOTTOM -> {
                    val lastY = (rect.bottom + dashLenght + offset).toFloat()
                    textLayoutParams.x = cenX.toInt() - textView.measuredWidth / 2 + mIndicatorRadius * 2
                    textLayoutParams.y = (lastY + textOffset).toInt()
                }

                Oritation.RIGHT -> {
                    val lastX = (rect.right + dashLenght + offset).toFloat()
                    textLayoutParams.x = (lastX + textOffset).toInt()
                    textLayoutParams.y = (cenY - textView.measuredHeight / 2).toInt()

                }

                Oritation.TOP -> {
                    val lastY = (rect.top - dashLenght - offset).toFloat()
                    textLayoutParams.x = cenX.toInt() - textView.measuredWidth / 2 + mIndicatorRadius * 2
                    textLayoutParams.y = (lastY - textOffset - textView.measuredHeight).toInt()

                }

                Oritation.LEFT_BOTTOM -> {
                    val lastX = cenX - offset - halfLenght
                    val lastY = (rect.bottom + dashLenght + offset).toFloat()

                    textLayoutParams.x = lastX.toInt()
                    textLayoutParams.y = (lastY + textOffset).toInt()
                }

                Oritation.RIGHT_BOTTOM -> {
                    val lastX = cenX + halfLenght + offset
                    val lastY = (rect.bottom + dashLenght + offset).toFloat()
                    textLayoutParams.x = lastX.toInt()
                    textLayoutParams.y = (lastY + textOffset).toInt()

                }

                Oritation.LEFT_TOP -> {
                    val lastX = cenX - halfLenght - offset
                    val lastY = (rect.top - dashLenght - offset).toFloat()
                    textLayoutParams.x = (lastX.toInt() - textView.paint.measureText(currentItem?.text)).toInt()
                    textLayoutParams.y = (lastY - textOffset - textView.measuredHeight).toInt()
                }

                Oritation.RIGHT_TOP -> {
                    val lastX = cenX + halfLenght + offset
                    val lastY = (rect.top - dashLenght - offset).toFloat()
                    textLayoutParams.x = lastX.toInt()
                    textLayoutParams.y = (lastY - textOffset - textView.measuredHeight).toInt()
                }
            }
        }
    }


    /**
     * 绘制背景
     */
    private fun drawMask(canvas: Canvas) {
        dashDrawable?.apply {
            canvas.save()
            mPaint.color = maskColor
            mPaint.xfermode = null
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), mPaint)
            mPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
            mPaint.color = Color.WHITE
            val radius = currentItem?.radius!!.toFloat()
            val rectf = RectF(currentItem?.rect)
            canvas.drawRoundRect(rectf, radius, radius, mPaint)
            bounds = currentItem?.rect!!
            draw(canvas)
            canvas.restore()
        }
    }

    /**
     * 绘制指示器
     */
    private fun drawIndicator(canvas: Canvas) {
        val x: Float = (textLayoutParams.x - 20 * dpBase - mIndicatorRadius).toFloat()
        val y: Float = textLayoutParams.y.toFloat() + textView.measuredHeight / 2

        mTextPaint.color = mIndicatorBg
        canvas.drawCircle(x, y, mIndicatorRadius.toFloat(), mTextPaint)

        val fontMetrics = mTextPaint.fontMetrics
        val textHeight = fontMetrics.descent - fontMetrics. ascent
        mTextPaint.color = mIndicatorColor
        canvas.drawText((currentIndex + 1).toString(), x, y + textHeight / 3, mTextPaint)
    }

    /**
     * 添加引导项
     */
    fun addGuildItem(item: GuideItem) {
        this.itemList.add(item)
        if (currentItem == null) {
            currentItem = item
            currentIndex = itemList.indexOf(item)
            invalidate()
            updateTextInfo()
        }
    }

    fun addGuideItems(items: ArrayList<GuideItem>) {
        if (items.isNotEmpty()) {
            this.itemList.clear()
            this.itemList.addAll(items)
            if (currentItem == null) {
                currentIndex = 0
                currentItem = items[currentIndex]
                invalidate()
                updateTextInfo()
            }
        }
    }

    private fun getNextItem() : GuideItem? {
        val index = currentIndex + 1
        if (index < itemList.size) {
            return itemList[index]
        }
        return null
    }

    fun next() {
        currentIndex++
        if (currentIndex >= itemList.size) {
            return
        }

        currentItem = itemList[currentIndex]
        updateTextInfo()
        updateTextLayoutParams()
        invalidate()
    }

    private fun setGuideFinish() {
        this.finish = true
        removeAllViews()
        itemList.clear()
    }

    private fun updateTextInfo() {
        currentItem?.run {
            textView.text = text
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean {
        if (finish || currentItem == null) {
            return  super.onInterceptTouchEvent(ev)
        }

        val continer = currentItem?.rect!!.contains(ev?.x!!.toInt(), ev.y.toInt())
        if (continer) {
            return !currentItem?.clickable!!
        }
        return true
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (finish || currentItem == null) {
            return super.onTouchEvent(event)
        }

        currentItem?.apply {

//            val continer = rect.contains(event?.x!!.toInt(), event.y.toInt())

//            if (continer) {
                if (event?.action == MotionEvent.ACTION_UP) {
                    if (!clickable) {
                        val nextItem = getNextItem()
                        if (nextItem == null) {
                            setGuideFinish()
                            finishListener?.onGuideFinish()
                        } else {
                            next()
                        }

                    } else {
                        val nextItem = getNextItem()
                        nextItem?.view?.performClick()
                    }
                }
//            }
        }
        return true
    }

    inner class LayoutParams(width: Int, height: Int) : ViewGroup.LayoutParams(width, height) {

        var x: Int = -1

        var y: Int = -1

    }

    /**
     * 引导提示显示位置
     */
    enum class Oritation {
        Left,
        TOP,
        LEFT_TOP,
        RIGHT,
        RIGHT_TOP,
        BOTTOM,
        RIGHT_BOTTOM,
        LEFT_BOTTOM
    }


    class GuideItem(/**需要引导的视图*/
                    val view: View,

                    /**
                     * 引导文字提示内容
                     */
                    val text: String = "",

                    /**
                     * 文字引导显示的方向
                     */
                    val oritation: Oritation,

                    /**
                     * 圆角角度大小
                     */
                    val radius: Int,
                    /**
                     * 控件是否支持点击. true: 控件自己处理点击事件, GuideView不做事件拦击处理. 接下来的引导需要手动调用next方法继续. false: GuideView拦截事件, 点击是继续下一步引导
                     */
                    val clickable: Boolean = false) {

        //使用懒加载实现
        val rect: Rect by lazy {
            val r = Rect()
            view.getHitRect(r)   //获取View在屏幕中显示的位置
            r
        }

        constructor(view: View, text: String = "", oritation: Oritation) : this(view, text, oritation, 0)


        fun getGuideRectCenterX() : Float {
            return rect.left + rect.width() / 2f
        }

        fun getGuideRectCenterY() : Float {
            return rect.top + rect.height() / 2f
        }
    }

    fun setGuildFinishListener(listener: OnGuidleFinishListener) {
        this.finishListener = listener
    }

    /**
     * 引导完成回调接口
     */
    interface OnGuidleFinishListener {
        abstract fun onGuideFinish()
    }
}