package com.wxq.guide.guideviewdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.Toast
import com.wxq.guide.lib.GuideView

class MainActivity : AppCompatActivity(), GuideView.OnGuidleFinishListener {

    private lateinit var guideView: GuideView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupView()
    }

    private fun setupView() {
        guideView = findViewById(R.id.guideview)
        val radius : Int =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 10f, resources.displayMetrics).toInt();
        val list = ArrayList<GuideView.GuideItem>()
        list.add(GuideView.GuideItem(findViewById(R.id.button), "第一个按钮", GuideView.Oritation.RIGHT_BOTTOM, radius, false))
        list.add(GuideView.GuideItem(findViewById(R.id.button2), "第二个按钮", GuideView.Oritation.LEFT_BOTTOM, radius, false))
        list.add(GuideView.GuideItem(findViewById(R.id.checkBox), "复选框", GuideView.Oritation.RIGHT_TOP, radius, false))
        list.add(GuideView.GuideItem(findViewById(R.id.radiogroup), "单选按钮", GuideView.Oritation.LEFT_TOP, radius, false))
        list.add(GuideView.GuideItem(findViewById(R.id.helloworld), "欢迎来到应到页", GuideView.Oritation.TOP, radius, false))
        guideView.addGuideItems(list)
        guideView.setGuildFinishListener(this)
    }

    override fun onGuideFinish() {
        Toast.makeText(this, "引导已完成", Toast.LENGTH_LONG).show()
    }


}